import React from "react";
import configuration from "react-global-configuration";

const AuthHeader = () => {
  return <></>;
};

export default AuthHeader;
