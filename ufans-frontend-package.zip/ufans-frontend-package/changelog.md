Version 7.0:

1. Chat - Auto scroll to bottom - Fixed
